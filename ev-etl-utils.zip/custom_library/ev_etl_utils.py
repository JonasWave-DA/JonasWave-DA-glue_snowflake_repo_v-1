"""
Custom Library para AWS Glue - Electric Vehicle ETL Utils
Funciones reutilizables para procesamiento de datos de vehículos eléctricos
"""

import json
import boto3
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DecimalType, TimestampType
from pyspark.sql.functions import col, trim, from_unixtime

class EVETLUtils:
    """Utilidades para ETL de vehículos eléctricos"""
    
    @staticmethod
    def get_snowflake_credentials(secret_name):
        """Obtener credenciales de Snowflake desde Secrets Manager"""
        secrets_client = boto3.client('secretsmanager')
        
        try:
            response = secrets_client.get_secret_value(SecretId=secret_name)
            return json.loads(response['SecretString'])
        except Exception as e:
            print(f"Error obteniendo credenciales: {e}")
            raise

    @staticmethod
    def read_json_from_s3(bucket, key):
        """Leer JSON desde S3 usando boto3"""
        s3_client = boto3.client('s3')
        
        response = s3_client.get_object(Bucket=bucket, Key=key)
        json_content = response['Body'].read().decode('utf-8')
        return json.loads(json_content)

    @staticmethod
    def extract_column_names(json_data):
        """Extraer nombres de columnas del JSON"""
        columns = json_data['meta']['view']['columns']
        return [col['name'] for col in columns]

    @staticmethod
    def extract_data_rows(json_data):
        """Extraer todas las filas de datos del JSON"""
        return json_data['data']

    @staticmethod
    def create_string_schema(column_names):
        """Crear esquema con todas las columnas como String"""
        return StructType([StructField(name, StringType(), True) for name in column_names])

    @staticmethod
    def select_and_transform_columns(df):
        """Seleccionar 25 columnas y convertir tipos de datos según Snowflake"""
        # Mapeo de columnas JSON a Snowflake
        column_mapping = {
            "sid": "SID",
            "id": "ID", 
            "position": "POSITION",
            "created_at": "CREATED_AT",
            "updated_at": "UPDATED_AT",
            "VIN (1-10)": "VIN_1_10",
            "County": "COUNTY",
            "City": "CITY",
            "State": "STATE",
            "Postal Code": "POSTAL_CODE",
            "Model Year": "MODEL_YEAR",
            "Make": "MAKE",
            "Model": "MODEL",
            "Electric Vehicle Type": "ELECTRIC_VEHICLE_TYPE",
            "Clean Alternative Fuel Vehicle (CAFV) Eligibility": "CLEAN_ALTERNATIVE_FUEL_VEHICLE_CAFV_ELIGIBILITY",
            "Electric Range": "ELECTRIC_RANGE",
            "Base MSRP": "BASE_MSRP",
            "Legislative District": "LEGISLATIVE_DISTRICT",
            "DOL Vehicle ID": "DOL_VEHICLE_ID",
            "Vehicle Location": "VEHICLE_LOCATION",
            "Electric Utility": "ELECTRIC_UTILITY",
            "2020 Census Tract": "2020_CENSUS_TRACT",
            "Counties": "COUNTIES",
            "Congressional Districts": "CONGRESSIONAL_DISTRICTS",
            "WAOFM - GIS - Legislative District Boundary": "WAOFM___GIS___LEGISLATIVE_DISTRICT_BOUNDARY"
        }
        
        # Seleccionar y renombrar columnas
        for old_name, new_name in column_mapping.items():
            if old_name in df.columns:
                df = df.withColumnRenamed(old_name, new_name)
        
        # Seleccionar solo las 25 columnas necesarias
        selected_columns = list(column_mapping.values())
        df = df.select(*[col for col in selected_columns if col in df.columns])
        
        # Convertir tipos de datos
        df = df.withColumn("POSITION", col("POSITION").cast(IntegerType())) \
               .withColumn("CREATED_AT", from_unixtime(col("CREATED_AT")).cast(TimestampType())) \
               .withColumn("UPDATED_AT", from_unixtime(col("UPDATED_AT")).cast(TimestampType())) \
               .withColumn("MODEL_YEAR", col("MODEL_YEAR").cast(IntegerType())) \
               .withColumn("ELECTRIC_RANGE", col("ELECTRIC_RANGE").cast(IntegerType())) \
               .withColumn("BASE_MSRP", col("BASE_MSRP").cast(DecimalType(12, 2))) \
               .withColumn("LEGISLATIVE_DISTRICT", col("LEGISLATIVE_DISTRICT").cast(IntegerType())) \
               .withColumn("COUNTIES", col("COUNTIES").cast(IntegerType())) \
               .withColumn("CONGRESSIONAL_DISTRICTS", col("CONGRESSIONAL_DISTRICTS").cast(IntegerType())) \
               .withColumn("WAOFM___GIS___LEGISLATIVE_DISTRICT_BOUNDARY", col("WAOFM___GIS___LEGISLATIVE_DISTRICT_BOUNDARY").cast(IntegerType()))
        
        return df

    @staticmethod
    def write_to_snowflake(df, snowflake_creds):
        """Escribir DataFrame a Snowflake"""
        
        snowflake_options = {
            "sfUrl": snowflake_creds['SNOWFLAKE_URL'],
            "sfUser": snowflake_creds['SNOWFLAKE_USER'],
            "sfPassword": snowflake_creds['SNOWFLAKE_PASSWORD'],
            "sfDatabase": snowflake_creds['SNOWFLAKE_DATABASE'],
            "sfSchema": snowflake_creds['SNOWFLAKE_SCHEMA'],
            "sfWarehouse": snowflake_creds['SNOWFLAKE_WAREHOUSE'],
            "dbtable": "ELECTRIC_VEHICLES_WA"
        }
        
        # Los nombres de columnas ya coinciden con Snowflake
        
        df.write \
            .format("snowflake") \
            .options(**snowflake_options) \
            .mode("overwrite") \
            .save()